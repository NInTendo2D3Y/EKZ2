﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp4.Pages
{
    public class SortItem
    {
        public string Name { get; set; }
        public SortDescription Description { get; set; }
    }
}
